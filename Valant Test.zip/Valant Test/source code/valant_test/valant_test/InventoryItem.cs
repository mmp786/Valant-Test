﻿namespace valant_test
{
    using System;
    public class InventoryItem
    {
        public string Label { get; set; }
        public DateTime Expiration { get; set; }
        public string Type { get; set; }
        public int Quantity { get; set; }
    }
}
